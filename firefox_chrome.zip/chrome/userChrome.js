console.log("test")
alert("test")