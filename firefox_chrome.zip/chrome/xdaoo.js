// ==UserScript==
// @name           customContextMenu.uc.js
// @description    定制右键菜单
// @author         myfreeer
// @include        chrome://browser/content/browser.xhtml
// @version        0.1.0
// ==/UserScript==
	
(function () {
	// 01 双击标签页关闭标签页
window.document.getElementsByTagName("tabs")[0].addEventListener("dblclick", function (event) {

    if (event.button == 0 && !event.ctrlKey) {
        const tab = event.target.closest('.tabbrowser-tab');
        if (!tab) return;
        // gBrowser.removeTab(tab);
        gBrowser.removeTab(tab, {animate: true});
    }
}, false);
	// 01 双击标签页关闭标签页Id
window.addEventListener("onkeypress",function(e){console.log(e)},false)


})();